<div class="serch-bar">
    <div id="custom-search-input">
        <div class="input-group col-md-12">
            <input type="search" wire:model="item" class="form-control input-lg" placeholder="Search" />
            <span class="input-group-btn">
                <button class="btn btn-info btn-lg" wire:click="search" type="button">
                    <i class="fa fa-search" aria-hidden="true"></i>
                </button>
            </span>
        </div>
    </div>
</div>
